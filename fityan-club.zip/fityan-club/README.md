# نادي فتيان أبها — دليل التشغيل والنشر

## ما يحتاجه الموقع
1. حساب GitHub (مجاني): https://github.com
2. حساب LiveKit Cloud (للصوت والفيديو): https://cloud.livekit.io
3. حساب Render (للاستضافة): https://render.com

## ملفات المشروع (ارفعها كما هي إلى GitHub)
server.js، package.json، مجلد public (وفيه assets/ataa-logo.png)، و README.md. لا ترفع node_modules ولا مجلد data ولا ملف .env.

## متغيرات البيئة (Environment Variables) في Render
| الاسم | القيمة |
|---|---|
| DATA_DIR | /var/data |
| SESSION_SECRET | أي نص عشوائي طويل (40 حرفاً أو أكثر) |
| SUPERVISOR_CODE | 1001 (أولي فقط، غيّره من الإعدادات بعد أول دخول) |
| ASSISTANT_CODE | 1001 (أولي فقط) |
| LIVEKIT_URL | wss://اسم-مشروعك.livekit.cloud |
| LIVEKIT_API_KEY | من لوحة LiveKit |
| LIVEKIT_API_SECRET | من لوحة LiveKit |

## إعدادات Render
Build Command: npm install | Start Command: npm start | Instance: Starter (مدفوع) | Disk: Mount Path /var/data، الحجم 1 GB.
القرص الدائم لا يعمل على الخطة المجانية، وبدونه تضيع الصور والبيانات عند كل إعادة تشغيل.

## تشغيل محلي (اختياري)
npm install ثم npm start، وافتح http://localhost:3000. المايك والكاميرا في المتصفح تتطلبان HTTPS أو localhost.

## صلاحيات المساعد (قابلة للتعديل من الإعدادات)
إدارة الاجتماعات، إضافة وتعديل الطلاب، إدارة الأغراض، والإشراف داخل الاجتماع. لا يحذف الطلاب ولا يغيّر الإعدادات والرموز ولا يرفع صور الأغراض نيابةً عن الطالب. تسمية المجموعة متاحة للمشرف والمساعد.

## ما لم يُختبر
فُحصت صياغة الكود فقط. لم يُجرَّب تشغيله على سيرفر حقيقي، ولا الاتصال الحي بين جهازين، ولا مشاركة الشاشة، ولا الرفع من الجوال.
